import { createHash, randomBytes } from "crypto";
import type {
  CreateApiKeyInput,
  CreateBulkJobInput,
  CreateJobInput,
  JobStatus,
  RequestMode,
} from "../shared/platform";
import {
  SAFE_TEST_SCENARIOS,
} from "../shared/platform";
import {
  buildSafeLeadImportPayloads,
  parseImportedLeadText,
  toSafeImportedLeadRecord,
} from "../shared/importedLeadFormat";
import { buildOneCsResult } from "../shared/oneCsScoring";
import {
  getDashboardSummary,
  getJobByPublicId,
  listApiKeysForUser,
  listAuditTrailEntries,
  listJobEventsByJobId,
  listJobs,
  listPayments,
  listPlans,
  listProxyPolicies,
  listProxyProviders,
  listSubscriptions,
  listWorkerNodes,
  persistApiKeyRecord,
  persistAuditTrailEntry,
  persistJobEvents,
  persistJobRecord,
  persistProxyLease,
  persistUsageRecord,
  persistWorkerRun,
  updateJobRecord,
} from "./db";
import {
  findMockJob,
  listMockJobEvents,
  MOCK_HEALTH_SUMMARY,
  MOCK_USAGE_SUMMARY,
} from "./platformMockData";
import { getCurrentPeriodKey, getRuntimeUsageSummary } from "./runtimeStore";

function createPublicId(prefix: string) {
  return `${prefix}_${randomBytes(6).toString("hex")}`;
}

function hashToken(raw: string) {
  return createHash("sha256").update(raw).digest("hex");
}

function estimateCost(mode: RequestMode, payloadSize: number) {
  const base = mode === "vip" ? 0.15 : mode === "bulk" ? 0.04 : 0.02;
  return Number((base + payloadSize / 10000).toFixed(4));
}

function nowIso() {
  return new Date().toISOString();
}

function toFiniteNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === "string" && value.trim().length > 0) {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) {
      return parsed;
    }
  }

  return null;
}

function toStringArray(value: unknown) {
  if (!Array.isArray(value)) {
    return [] as string[];
  }

  return value
    .filter((item): item is string => typeof item === "string")
    .map(item => item.trim())
    .filter(Boolean);
}

function inferOneCsCreditScore(payload: Record<string, unknown>) {
  return toFiniteNumber(payload.creditScore) ?? toFiniteNumber(payload.rawCreditScore) ?? null;
}

function inferOneCsCompletenessScore(payload: Record<string, unknown>) {
  const candidate = toFiniteNumber(payload.completenessScore) ?? toFiniteNumber(payload.dataCompletenessScore);
  if (candidate === null) {
    return undefined;
  }

  return Math.min(1, Math.max(0, candidate));
}

function inferOneCsAdverseReasons(payload: Record<string, unknown>, creditScore: number | null) {
  const explicitReasons = toStringArray(payload.adverseReasons);
  if (explicitReasons.length > 0) {
    return explicitReasons;
  }

  const inferred = new Set<string>();

  if (payload.noCreditProfile === true) {
    inferred.add("Unable to find credit profile at TransUnion");
  }
  if (payload.thinFile === true) {
    inferred.add("Insufficient length of credit history");
  }
  if (payload.highUtilization === true) {
    inferred.add("Proportion of balances to credit limits on bank/national revolving or other revolving accounts is too high");
  }
  if (payload.highDebtToIncome === true) {
    inferred.add("High debt in relation to income");
  }
  if (payload.recentInquiries === true) {
    inferred.add("RiskView Consumer Inquiry");
  }

  if (creditScore === null && inferred.size === 0) {
    inferred.add("Insufficient credit history");
  } else if (creditScore !== null) {
    if (creditScore < 480) {
      inferred.add("Serious delinquency, and public record or collection filed");
      inferred.add("High debt in relation to income");
    } else if (creditScore < 560) {
      inferred.add("Serious delinquency");
      inferred.add("Too many accounts with balances");
      inferred.add("Proportion of balances to credit limits on bank/national revolving or other revolving accounts is too high");
    } else if (creditScore < 640) {
      inferred.add("Income or credit history insufficient for loan");
      inferred.add("Requested amount unsupported by income");
    } else if (creditScore < 720) {
      inferred.add("RiskView Consumer Inquiry");
    }
  }

  return Array.from(inferred);
}

function inferOneCsPriceUsd(mode: RequestMode, payload: Record<string, unknown>, estimatedCostUsd: number) {
  const explicitPrice =
    toFiniteNumber(payload.priceUsd) ??
    toFiniteNumber(payload.chargedPriceUsd) ??
    toFiniteNumber(payload.requestPriceUsd);

  if (explicitPrice !== null) {
    return explicitPrice;
  }

  const defaults: Record<RequestMode, number> = {
    single: 1.9,
    bulk: 1.7,
    vip: 2.5,
  };

  return Number(Math.max(defaults[mode], estimatedCostUsd * 2.75).toFixed(2));
}

export function buildApiResponse<T>(requestId: string, data: T, meta?: Record<string, unknown>) {
  return {
    ok: true,
    requestId,
    data,
    meta,
  } as const;
}

export function buildApiError(
  requestId: string,
  code: string,
  message: string,
  retryable = false,
  details?: Record<string, unknown>,
) {
  return {
    ok: false,
    requestId,
    error: {
      code,
      message,
      retryable,
      details,
    },
  } as const;
}

export async function getAdminOverview() {
  const summary = await getDashboardSummary();
  const [plans, subscriptions, payments, auditTrail] = await Promise.all([
    listPlans(),
    listSubscriptions(),
    listPayments(),
    listAuditTrailEntries(),
  ]);

  return {
    ...summary,
    plans,
    subscriptions,
    payments,
    auditTrail: auditTrail.slice(0, 10),
    safeTestScenarios: SAFE_TEST_SCENARIOS,
  };
}

export async function getJobsModule() {
  const jobs = await listJobs();

  const enriched = await Promise.all(
    jobs.map(async job => ({
      ...job,
      events: await listJobEventsByJobId(job.id),
    })),
  );

  return enriched;
}

export async function getJobDetails(publicId: string) {
  const job = await getJobByPublicId(publicId);
  if (!job) {
    return null;
  }

  const events = await listJobEventsByJobId(job.id);
  return {
    job,
    events,
  };
}

export async function getProxyModule() {
  const [providers, policies] = await Promise.all([listProxyProviders(), listProxyPolicies()]);

  const providerHealth = providers.map(provider => ({
    code: provider.code,
    name: provider.name,
    status: provider.status,
    priority: provider.priority,
    protocolSupport: provider.protocolSupport,
    sessionSupport: provider.sessionSupport,
    costPerGbUsd: provider.costPerGbUsd,
    healthScore:
      provider.status === "healthy" ? 0.98 : provider.status === "degraded" ? 0.72 : 0.1,
    lastCheckedAt: nowIso(),
  }));

  return {
    providers,
    policies,
    providerHealth,
    routingPrinciples: {
      selectionOrder: providers.sort((a, b) => a.priority - b.priority).map(provider => provider.code),
      fallbackEnabled: true,
      stickySupported: true,
      rotatingSupported: true,
      trafficAccounting: true,
    },
  };
}

export async function getWorkersModule() {
  const workers = await listWorkerNodes();

  return {
    workers,
    queueHealth: MOCK_HEALTH_SUMMARY.queues,
    recommendations: [
      "Keep VIP queue lag under 10 seconds.",
      "Trigger maintenance mode when heartbeat gap exceeds 60 seconds.",
      "Use safe test scenarios before changing routing or retry policies.",
    ],
  };
}

export async function getBillingModule() {
  const [plans, subscriptions, payments, apiKeys] = await Promise.all([
    listPlans(),
    listSubscriptions(),
    listPayments(),
    listApiKeysForUser(),
  ]);

  return {
    plans,
    subscriptions,
    payments,
    apiKeys,
    usageSummary: getRuntimeUsageSummary() ?? MOCK_USAGE_SUMMARY,
  };
}

export async function getTelemetryModule() {
  const [jobs, providers, workers, auditTrail] = await Promise.all([
    listJobs(),
    listProxyProviders(),
    listWorkerNodes(),
    listAuditTrailEntries(),
  ]);

  const counts = jobs.reduce(
    (acc, job) => {
      acc.total += 1;
      acc[job.status] = (acc[job.status] ?? 0) + 1;
      return acc;
    },
    {
      total: 0,
      queued: 0,
      running: 0,
      succeeded: 0,
      failed: 0,
      canceled: 0,
      waiting_retry: 0,
    } as Record<string, number>,
  );

  const successRate = counts.total > 0 ? counts.succeeded / counts.total : 0;
  const retryRate = counts.total > 0 ? counts.waiting_retry / counts.total : 0;

  return {
    health: MOCK_HEALTH_SUMMARY,
    jobStatusCounts: counts,
    successRate,
    retryRate,
    providers,
    workers,
    recentAudit: auditTrail.slice(0, 20),
  };
}

export async function getSystemModule() {
  return {
    health: MOCK_HEALTH_SUMMARY,
    safeTestScenarios: SAFE_TEST_SCENARIOS,
    stabilizationChecklist: [
      "Rate limit all public REST endpoints.",
      "Emit audit events for administrative mutations.",
      "Keep proxy fallback paths observable in job events.",
      "Never execute external protected flows from the safe test bench.",
    ],
  };
}

function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function executeQueuedJobLifecycle(params: {
  job: Awaited<ReturnType<typeof persistJobRecord>>;
  input: CreateJobInput;
  actor: { userId?: number; source: "dashboard" | "api" | "testbench" };
  providerHint: string;
  fallbackProvider: string;
  durationMs: number;
  oneCsResult: ReturnType<typeof buildOneCsResult>;
  summary: {
    creditScore: number | null;
    productScore: number;
    dataQualityScore: number;
    status: string;
    adverseReasonCount: number;
  };
}) {
  const { job, input, actor, providerHint, fallbackProvider, durationMs, oneCsResult, summary } = params;
  const startedAt = new Date();

  await updateJobRecord(job.publicId, {
    status: input.payload.simulateRetryableError === true ? "waiting_retry" : "running",
    startedAt,
    attemptCount: 1,
    workerNodeId: 1,
  });

  await persistJobEvents([
    {
      jobId: job.id,
      eventType: input.payload.simulateRetryableError === true ? "job.waiting_retry" : "worker.started",
      severity: input.payload.simulateRetryableError === true ? "warn" : "info",
      message:
        input.payload.simulateRetryableError === true
          ? `Job ${job.publicId} entered retry wait state after first dispatch attempt.`
          : `Worker picked up job ${job.publicId} from queue ${job.queueName}.`,
      eventJson:
        input.payload.simulateRetryableError === true
          ? { retryable: true, nextAttempt: 2, providerHint }
          : { workerNodeId: 1, providerHint, actorSource: actor.source },
      createdAt: startedAt,
    },
  ]);

  await persistWorkerRun({
    jobId: job.id,
    workerNodeId: 1,
    runStatus: input.payload.simulateRetryableError === true ? "failed" : "started",
    attemptNumber: 1,
    profilePolicy: input.profilePolicy ?? null,
    fingerprintProfile: input.fingerprintProfile ?? null,
    runtimeMs: input.payload.simulateRetryableError === true ? Math.round(durationMs * 0.35) : null,
    detailsJson: {
      executionMode: "queued_runtime",
      providerUsed: providerHint,
      fallbackProvider,
      safeTestMode: false,
    },
    createdAt: startedAt,
    finishedAt: input.payload.simulateRetryableError === true ? new Date(startedAt.getTime() + Math.round(durationMs * 0.35)) : null,
  });

  if (input.payload.simulateRetryableError === true) {
    await sleep(350);
    const completedAt = new Date();
    const resultJson = {
      mode: input.requestMode,
      safeTestMode: false,
      providerUsed: providerHint,
      fallbackPrepared: true,
      recoveredAfterRetry: true,
      completedAt: completedAt.toISOString(),
      executionState: "completed_after_retry",
      oneCsResult,
      summary,
    };

    await updateJobRecord(job.publicId, {
      status: "succeeded",
      resultJson,
      errorCode: null,
      errorMessage: null,
      attemptCount: 2,
      completedAt,
    });

    await persistJobEvents([
      {
        jobId: job.id,
        eventType: "worker.retried",
        severity: "info",
        message: `Job ${job.publicId} succeeded on retry attempt with provider ${providerHint}.`,
        eventJson: { attemptNumber: 2, providerHint, fallbackProvider },
        createdAt: completedAt,
      },
      {
        jobId: job.id,
        eventType: "job.completed",
        severity: "info",
        message: `Job ${job.publicId} completed after retry recovery.`,
        eventJson: { durationMs, status: oneCsResult.status },
        createdAt: completedAt,
      },
    ]);

    await persistWorkerRun({
      jobId: job.id,
      workerNodeId: 1,
      runStatus: "completed",
      attemptNumber: 2,
      profilePolicy: input.profilePolicy ?? null,
      fingerprintProfile: input.fingerprintProfile ?? null,
      runtimeMs: durationMs,
      detailsJson: {
        executionMode: "queued_runtime",
        retried: true,
        providerUsed: providerHint,
      },
      createdAt: completedAt,
      finishedAt: completedAt,
    });

    return;
  }

  await sleep(250);
  const completedAt = new Date();
  const resultJson = {
    mode: input.requestMode,
    safeTestMode: false,
    providerUsed: providerHint,
    fallbackPrepared: true,
    completedAt: completedAt.toISOString(),
    executionState: "completed_by_worker",
    oneCsResult,
    summary,
  };

  await updateJobRecord(job.publicId, {
    status: "succeeded",
    resultJson,
    errorCode: null,
    errorMessage: null,
    completedAt,
  });

  await persistJobEvents([
    {
      jobId: job.id,
      eventType: "worker.completed",
      severity: "info",
      message: `Worker completed job ${job.publicId}.`,
      eventJson: { durationMs, providerHint },
      createdAt: completedAt,
    },
    {
      jobId: job.id,
      eventType: "job.completed",
      severity: "info",
      message: `Job ${job.publicId} completed in queued runtime mode.`,
      eventJson: { durationMs, status: oneCsResult.status },
      createdAt: completedAt,
    },
  ]);

  await persistWorkerRun({
    jobId: job.id,
    workerNodeId: 1,
    runStatus: "completed",
    attemptNumber: 1,
    profilePolicy: input.profilePolicy ?? null,
    fingerprintProfile: input.fingerprintProfile ?? null,
    runtimeMs: durationMs,
    detailsJson: {
      executionMode: "queued_runtime",
      providerUsed: providerHint,
      fallbackProvider,
    },
    createdAt: completedAt,
    finishedAt: completedAt,
  });
}

export async function createSingleJob(input: CreateJobInput, actor: { userId?: number; source: "dashboard" | "api" | "testbench" }) {
  const requestId = createPublicId("req");
  const publicId = createPublicId("job");
  const payloadSize = JSON.stringify(input.payload).length;
  const estimatedCostUsd = estimateCost(input.requestMode, payloadSize);
  const now = new Date();
  const safeTestMode = input.safeTestMode === true;

  const baseStatus: JobStatus = safeTestMode ? "succeeded" : "queued";
  const providerHint = input.proxy?.providerHint ?? "evomi";
  const fallbackProvider = providerHint === "evomi" ? "dataimpulse" : "evomi";
  const payloadRecord = input.payload as Record<string, unknown>;
  const creditScore = inferOneCsCreditScore(payloadRecord);
  const completenessScore = inferOneCsCompletenessScore(payloadRecord);
  const adverseReasons = inferOneCsAdverseReasons(payloadRecord, creditScore);
  const durationMs = Math.round(
    toFiniteNumber(payloadRecord.durationMs) ??
      (input.requestMode === "vip" ? 28_000 : input.requestMode === "bulk" ? 24_000 : 19_000),
  );
  const oneCsResult = buildOneCsResult({
    creditScore,
    completenessScore,
    adverseReasons,
    priceUsd: inferOneCsPriceUsd(input.requestMode, payloadRecord, estimatedCostUsd),
    durationMs,
    source: actor.source,
  });
  const summary = {
    creditScore: oneCsResult.creditScore,
    productScore: oneCsResult.productScore,
    dataQualityScore: oneCsResult.dataQualityScore,
    status: oneCsResult.status,
    adverseReasonCount: oneCsResult.adverseReasons.length,
  };

  const resultJson = safeTestMode
    ? {
        mode: input.requestMode,
        safeTestMode: true,
        providerUsed: providerHint,
        fallbackPrepared: true,
        extractedAt: nowIso(),
        oneCsResult,
        summary,
      }
    : {
        mode: input.requestMode,
        safeTestMode: false,
        providerUsed: providerHint,
        fallbackPrepared: true,
        queuedAt: nowIso(),
        executionState: "queued_for_worker",
        summary,
      };

  const job = await persistJobRecord({
    publicId,
    userId: actor.userId ?? null,
    apiKeyId: null,
    source: actor.source,
    requestMode: input.requestMode,
    status: baseStatus,
    queueName: input.queueName,
    priority: input.priority,
    targetLabel: input.targetLabel ?? null,
    payloadJson: input.payload,
    resultJson,
    errorCode: null,
    errorMessage: null,
    proxyPolicyId: null,
    workerNodeId: 1,
    attemptCount: safeTestMode ? 1 : 0,
    maxAttempts: input.proxy?.maxTransportRetries ? input.proxy.maxTransportRetries + 1 : 3,
    costEstimateUsd: estimatedCostUsd.toFixed(4),
    cogsUsd: (estimatedCostUsd * 0.55).toFixed(4),
    createdAt: now,
    startedAt: safeTestMode ? now : null,
    completedAt: safeTestMode ? now : null,
  });

  const events: Array<{
    type: string;
    severity: "info" | "warn" | "error";
    message: string;
    details: Record<string, unknown>;
  }> = [
    {
      type: "job.created",
      severity: "info",
      message: `Job ${publicId} created in ${safeTestMode ? "safe test" : "queued runtime"} mode.`,
      details: {
        requestMode: input.requestMode,
        queueName: input.queueName,
        providerHint,
      },
    },
    {
      type: "proxy.selection",
      severity: "info",
      message: `Primary provider selected: ${providerHint}.`,
      details: {
        providerHint,
        fallbackProvider,
        sessionMode: input.proxy?.sessionMode ?? "rotating",
      },
    },
  ];

  if (safeTestMode) {
    events.push({
      type: "job.completed",
      severity: "info",
      message: `Job ${publicId} completed inside the safe test bench.`,
      details: {
        durationMs,
        status: oneCsResult.status,
      },
    });
  } else {
    events.push({
      type: "job.queued",
      severity: "info",
      message: `Job ${publicId} accepted into queue ${input.queueName}.`,
      details: {
        queueName: input.queueName,
        maxAttempts: input.proxy?.maxTransportRetries ? input.proxy.maxTransportRetries + 1 : 3,
      },
    });
  }

  if (input.payload.simulateProviderFailure === true) {
    events.push({
      type: "proxy.provider_fallback",
      severity: "warn",
      message: `Primary provider ${providerHint} marked degraded, fallback prepared: ${fallbackProvider}.`,
      details: { from: providerHint, to: fallbackProvider },
    });
  }

  if (input.payload.simulateRetryableError === true) {
    events.push({
      type: "job.waiting_retry",
      severity: "warn",
      message: "Retryable error simulated for stability validation.",
      details: { retryable: true, nextAttempt: 2 },
    });
  }

  await persistJobEvents(
    events.map(event => ({
      jobId: job.id,
      eventType: event.type,
      severity: event.severity,
      message: event.message,
      eventJson: event.details,
      createdAt: now,
    })),
  );
  const savedEvents = await listJobEventsByJobId(job.id);
  const apiEvents = savedEvents.map(event => ({
    id: event.id,
    jobId: event.jobId,
    type: event.eventType,
    severity: event.severity,
    message: event.message,
    details: event.eventJson as Record<string, unknown>,
    createdAt: event.createdAt,
  }));

  await persistProxyLease({
    leaseId: createPublicId("lease"),
    jobId: job.id,
    workerNodeId: 1,
    providerId: providerHint === "dataimpulse" ? 2 : 1,
    policyId: null,
    protocol: input.proxy?.protocol ?? "http",
    sessionMode: input.proxy?.sessionMode ?? "rotating",
    sessionKey: safeTestMode ? `safe_${publicId}` : `queue_${publicId}`,
    endpointHost: `${providerHint}.proxy.internal`,
    endpointPort: input.proxy?.protocol === "socks5" ? 1080 : 9000,
    country: input.proxy?.country ?? null,
    status: safeTestMode ? "released" : "active",
    bytesSent: Math.max(256, payloadSize),
    bytesReceived: Math.max(512, Math.round(payloadSize * 1.5)),
    estimatedCostUsd: estimatedCostUsd.toFixed(4),
    lastErrorCode: input.payload.simulateProviderFailure === true ? "PROVIDER_DEGRADED" : null,
    metadataJson: {
      providerHint,
      fallbackProvider,
      targetLabel: input.targetLabel ?? null,
    },
    createdAt: now,
    expiresAt: safeTestMode ? now : new Date(now.getTime() + 15 * 60 * 1000),
    releasedAt: safeTestMode ? now : null,
  });

  if (safeTestMode) {
    await persistWorkerRun({
      jobId: job.id,
      workerNodeId: 1,
      runStatus: "completed",
      attemptNumber: 1,
      profilePolicy: input.profilePolicy ?? null,
      fingerprintProfile: input.fingerprintProfile ?? null,
      runtimeMs: durationMs,
      detailsJson: {
        safeTestMode: true,
        providerUsed: providerHint,
      },
      createdAt: now,
      finishedAt: now,
    });
  }

  const unitCostUsd = estimatedCostUsd;
  const revenueUsd = inferOneCsPriceUsd(input.requestMode, payloadRecord, estimatedCostUsd);
  await persistUsageRecord({
    userId: actor.userId ?? null,
    apiKeyId: null,
    jobId: job.id,
    metricType: input.requestMode === "bulk" ? "bulk_item" : "request",
    quantity: "1.0000",
    unitCostUsd: unitCostUsd.toFixed(4),
    totalCostUsd: unitCostUsd.toFixed(4),
    periodKey: getCurrentPeriodKey(now),
    metadataJson: {
      requestMode: input.requestMode,
      revenueUsd,
      safeTestMode,
    },
    createdAt: now,
  });

  if (input.requestMode === "vip") {
    await persistUsageRecord({
      userId: actor.userId ?? null,
      apiKeyId: null,
      jobId: job.id,
      metricType: "browser_run",
      quantity: "1.0000",
      unitCostUsd: "0.0000",
      totalCostUsd: "0.0000",
      periodKey: getCurrentPeriodKey(now),
      metadataJson: {
        source: actor.source,
        safeTestMode,
      },
      createdAt: now,
    });
  }

  await persistAuditTrailEntry({
    actorUserId: actor.userId ?? null,
    actorType: actor.source === "api" ? "api_key" : "user",
    action: "job.create",
    resourceType: "job",
    resourceId: publicId,
    status: "success",
    ipAddress: null,
    detailsJson: {
      requestMode: input.requestMode,
      queueName: input.queueName,
      safeTestMode,
      providerHint,
    },
    createdAt: now,
  });

  if (!safeTestMode) {
    void executeQueuedJobLifecycle({
      job,
      input,
      actor,
      providerHint,
      fallbackProvider,
      durationMs,
      oneCsResult,
      summary,
    }).catch(error => {
      console.error(`[ONE CS] queued job lifecycle failed for ${job.publicId}`, error);
    });
  }

  return buildApiResponse(requestId, { job, events: apiEvents }, {
    safeTestMode,
    persisted: true,
    executionMode: safeTestMode ? "safe_test" : "queued_runtime",
  });
}

export async function createBulkJob(input: CreateBulkJobInput, actor: { userId?: number; source: "api" | "dashboard" | "testbench" }) {
  const requestId = createPublicId("req");

  const items = input.items.map((item, index) => {
    const syntheticInput: CreateJobInput = {
      requestMode: "bulk",
      queueName: input.queueName,
      priority: input.priority,
      payload: item.payload,
      proxy: input.proxy,
      safeTestMode: input.safeTestMode,
      targetLabel: item.externalId ?? `bulk-item-${index + 1}`,
    };

    return createSingleJob(syntheticInput, actor);
  });

  const resolved = await Promise.all(items);

  return buildApiResponse(
    requestId,
    {
      batchId: createPublicId("batch"),
      itemCount: resolved.length,
      jobs: resolved.map(result => result.data.job),
    },
    {
      safeTestMode: input.safeTestMode,
      queueName: input.queueName,
    },
  );
}

export async function createApiKeyRecord(userId: number, input: CreateApiKeyInput) {
  const rawToken = `cs_${input.scope}_${randomBytes(18).toString("hex")}`;
  const keyPrefix = rawToken.slice(0, 16);
  const now = new Date();
  const record = await persistApiKeyRecord({
    userId,
    label: input.label,
    keyPrefix,
    keyHash: hashToken(rawToken),
    scope: input.scope,
    status: "active",
    rpmLimit: input.rpmLimit,
    dailyLimit: input.dailyLimit,
    createdAt: now,
    updatedAt: now,
    expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
    lastUsedAt: null,
  });

  await persistAuditTrailEntry({
    actorUserId: userId,
    actorType: "user",
    action: "apikey.create",
    resourceType: "api_key",
    resourceId: keyPrefix,
    status: "success",
    ipAddress: null,
    detailsJson: {
      scope: input.scope,
      rpmLimit: input.rpmLimit,
      dailyLimit: input.dailyLimit,
    },
    createdAt: now,
  });

  return {
    preview: rawToken,
    record,
  };
}

export async function getSafeTestBench() {
  return {
    scenarios: SAFE_TEST_SCENARIOS,
    mockHealth: MOCK_HEALTH_SUMMARY,
    sampleJob: findMockJob("job_mock_success_001"),
    sampleEvents: listMockJobEvents(1),
    guidance: [
      "Use safe test mode for all manual validation before enabling real integrations.",
      "Validate queue transitions, proxy fallback, rate limiting and audit events independently.",
      "Treat all simulated transport failures as opportunities to inspect observability paths.",
      "Redact sensitive imported records before converting them into queue payloads.",
    ],
  };
}

export async function previewImportedLeadText(inputText: string) {
  const parsed = parseImportedLeadText(inputText);
  const safeRecords = parsed.map(toSafeImportedLeadRecord);
  const stateBreakdown = safeRecords.reduce<Record<string, number>>((acc, record) => {
    const key = record.state ?? "unknown";
    acc[key] = (acc[key] ?? 0) + 1;
    return acc;
  }, {});

  return {
    totalRecords: safeRecords.length,
    sourceLabels: Array.from(new Set(safeRecords.map(record => record.sourceLabel).filter(Boolean))),
    stateBreakdown,
    withPhone: safeRecords.filter(record => record.phoneNumbers.length > 0).length,
    withEmailDomain: safeRecords.filter(record => Boolean(record.emailDomain)).length,
    withDob: safeRecords.filter(record => Boolean(record.dobText)).length,
    withSsnMarker: safeRecords.filter(record => record.hasSsn).length,
    averageCompletenessScore:
      safeRecords.length > 0
        ? Number(
            (
              safeRecords.reduce((sum, record) => sum + record.completenessScore, 0) /
              safeRecords.length
            ).toFixed(2),
          )
        : 0,
    sampleRecords: safeRecords.slice(0, 10),
    safePayloads: buildSafeLeadImportPayloads(inputText).slice(0, 25),
  };
}

export async function createSafeImportedLeadBatch(
  inputText: string,
  actor: { userId?: number; source: "api" | "dashboard" | "testbench" },
) {
  const safePayloads = buildSafeLeadImportPayloads(inputText);

  return createBulkJob(
    {
      queueName: "lead-import",
      priority: 110,
      safeTestMode: true,
      items: safePayloads.map((payload, index) => ({
        externalId: payload.targetLabel ?? `lead-import-${index + 1}`,
        payload: payload.payload,
      })),
    },
    actor,
  );
}

export async function getApiUsageSummary() {
  const apiKeys = await listApiKeysForUser();
  return {
    apiKeys,
    usageSummary: getRuntimeUsageSummary() ?? MOCK_USAGE_SUMMARY,
  };
}

export function assertVipScope(scope: string) {
  return scope === "vip" || scope === "admin";
}

export function deriveRateLimit(scope: string) {
  switch (scope) {
    case "admin":
      return { rpm: 600, daily: 100000 };
    case "vip":
      return { rpm: 300, daily: 25000 };
    case "bulk":
      return { rpm: 120, daily: 5000 };
    default:
      return { rpm: 60, daily: 1000 };
  }
}
