import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createApiKeySchema,
  createBulkJobSchema,
  createJobSchema,
  jobFilterSchema,
  metricFilterSchema,
} from "../shared/platform";
import {
  createApiKeyRecord,
  createBulkJob,
  createSafeImportedLeadBatch,
  createSingleJob,
  getAdminOverview,
  getApiUsageSummary,
  getBillingModule,
  getJobDetails,
  getJobsModule,
  getProxyModule,
  getSafeTestBench,
  getSystemModule,
  getTelemetryModule,
  getWorkersModule,
  previewImportedLeadText,
} from "./platformService";

const jobsRouter = router({
  list: adminProcedure.input(jobFilterSchema.optional()).query(async () => {
    return getJobsModule();
  }),
  get: protectedProcedure
    .input(z.object({ publicId: z.string().min(3).max(64) }))
    .query(async ({ input }) => {
      return getJobDetails(input.publicId);
    }),
  createSafeSingle: adminProcedure.input(createJobSchema).mutation(async ({ ctx, input }) => {
    return createSingleJob(
      {
        ...input,
        safeTestMode: true,
      },
      { userId: ctx.user.id, source: "dashboard" },
    );
  }),
  createSafeBulk: adminProcedure.input(createBulkJobSchema).mutation(async ({ ctx, input }) => {
    return createBulkJob(
      {
        ...input,
        safeTestMode: true,
      },
      { userId: ctx.user.id, source: "dashboard" },
    );
  }),
});

const proxiesRouter = router({
  summary: adminProcedure.query(async () => {
    return getProxyModule();
  }),
});

const workersRouter = router({
  summary: adminProcedure.query(async () => {
    return getWorkersModule();
  }),
});

const billingRouter = router({
  summary: adminProcedure.query(async () => {
    return getBillingModule();
  }),
  usage: protectedProcedure.query(async () => {
    return getApiUsageSummary();
  }),
});

const telemetryRouter = router({
  summary: adminProcedure.input(metricFilterSchema.optional()).query(async () => {
    return getTelemetryModule();
  }),
});

const platformRouter = router({
  overview: adminProcedure.query(async () => {
    return getAdminOverview();
  }),
  system: adminProcedure.query(async () => {
    return getSystemModule();
  }),
  safeTestBench: adminProcedure.query(async () => {
    return getSafeTestBench();
  }),
});

const apiKeysRouter = router({
  create: protectedProcedure.input(createApiKeySchema).mutation(async ({ ctx, input }) => {
    return createApiKeyRecord(ctx.user.id, input);
  }),
  usage: protectedProcedure.query(async () => {
    return getApiUsageSummary();
  }),
});

const importedDataRouter = router({
  preview: adminProcedure
    .input(z.object({ inputText: z.string().min(1).max(200000) }))
    .mutation(async ({ input }) => {
      return previewImportedLeadText(input.inputText);
    }),
  createSafeBatch: adminProcedure
    .input(z.object({ inputText: z.string().min(1).max(200000) }))
    .mutation(async ({ ctx, input }) => {
      return createSafeImportedLeadBatch(input.inputText, {
        userId: ctx.user.id,
        source: "dashboard",
      });
    }),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  jobs: jobsRouter,
  proxies: proxiesRouter,
  workers: workersRouter,
  billing: billingRouter,
  telemetry: telemetryRouter,
  platform: platformRouter,
  apiKeys: apiKeysRouter,
  importedData: importedDataRouter,
  publicApi: router({
    health: publicProcedure.query(async () => {
      const system = await getSystemModule();
      return system.health;
    }),
  }),
});

export type AppRouter = typeof appRouter;
