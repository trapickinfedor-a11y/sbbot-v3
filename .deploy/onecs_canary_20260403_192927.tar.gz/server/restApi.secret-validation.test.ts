import express from "express";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { registerRestApi } from "./restApi";

let server: ReturnType<express.Express["listen"]> | null = null;
let baseUrl = "";

describe("legacy secret migration validation", () => {
  beforeAll(async () => {
    const app = express();
    app.use(express.json());
    registerRestApi(app);

    await new Promise<void>((resolve) => {
      server = app.listen(0, "127.0.0.1", () => {
        const address = server?.address();
        if (!address || typeof address === "string") {
          throw new Error("Failed to bind test server");
        }
        baseUrl = `http://127.0.0.1:${address.port}`;
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve, reject) => {
      if (!server) {
        resolve();
        return;
      }

      server.close((error) => {
        if (error) {
          reject(error);
          return;
        }
        resolve();
      });
    });
  });

  it("accepts migrated PRIVATE_API_KEY on protected usage summary endpoint", async () => {
    const migratedApiKey = process.env.PRIVATE_API_KEY;

    expect(typeof migratedApiKey).toBe("string");
    expect(migratedApiKey?.length ?? 0).toBeGreaterThan(16);

    const response = await fetch(`${baseUrl}/api/v1/usage/summary`, {
      headers: {
        Authorization: `Bearer ${migratedApiKey}`,
      },
    });

    expect(response.status).toBe(200);

    const payload = (await response.json()) as {
      ok: boolean;
      data?: {
        apiKeys?: Array<{ keyPrefix: string }>;
        usageSummary?: {
          requests?: number;
        };
      };
    };

    expect(payload.ok).toBe(true);
    expect(Array.isArray(payload.data?.apiKeys ?? [])).toBe(true);
    expect(typeof payload.data?.usageSummary?.requests).toBe("number");
    expect((payload.data?.usageSummary?.requests ?? 0) > 0).toBe(true);
  });
});
