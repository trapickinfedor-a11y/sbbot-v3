import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Empty, EmptyDescription, EmptyHeader, EmptyTitle } from "@/components/ui/empty";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { AlertCircle, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";

type PageKey = "jobs" | "proxy" | "workers" | "billing" | "telemetry" | "system";

type HealthSnapshot = {
  status?: string;
  queues?: Record<string, { depth: number; lagSeconds: number }>;
  providers?: Record<string, { status?: string; successRate?: number; avgLeaseMs?: number }>;
  workers?: { total?: number; healthy?: number };
};

export const pageMeta: Record<PageKey, { title: string; description: string }> = {
  jobs: {
    title: "Jobs",
    description: "Операторский обзор очередей, статусов, попыток и событий по заданиям.",
  },
  proxy: {
    title: "Proxy",
    description: "Текущая read-only сводка по провайдерам, policy и health fallback-контуру.",
  },
  workers: {
    title: "Workers",
    description: "Контроль worker-узлов, concurrency, heartbeat и безопасных execution-рекомендаций.",
  },
  billing: {
    title: "Billing",
    description: "Тарифы, подписки, платежи и usage economics по уже реализованному billing-модулю.",
  },
  telemetry: {
    title: "Metrics",
    description: "Системная телеметрия, queue health, success rate, retry rate и последние audit-события.",
  },
  system: {
    title: "System",
    description: "Системный статус, checklist стабилизации и safe-test сценарии для операторской проверки.",
  },
};

const toneMap: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
  healthy: "secondary",
  active: "secondary",
  succeeded: "secondary",
  running: "secondary",
  confirmed: "secondary",
  degraded: "outline",
  waiting_retry: "outline",
  pending: "outline",
  disabled: "destructive",
  failed: "destructive",
  offline: "destructive",
  expired: "destructive",
  refunded: "outline",
  maintenance: "outline",
};

export default function Operations() {
  const [location] = useLocation();
  const pageKey = resolvePageKey(location);
  const meta = pageMeta[pageKey];

  const jobsQuery = trpc.jobs.list.useQuery();
  const proxyQuery = trpc.proxies.summary.useQuery();
  const workersQuery = trpc.workers.summary.useQuery();
  const billingQuery = trpc.billing.summary.useQuery();
  const telemetryQuery = trpc.telemetry.summary.useQuery();
  const systemQuery = trpc.platform.system.useQuery();

  const queries = [jobsQuery, proxyQuery, workersQuery, billingQuery, telemetryQuery, systemQuery];
  const firstError = queries.find(query => query.error)?.error;
  const isAnyLoading = queries.some(query => query.isLoading);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <section className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="space-y-1">
                  <CardTitle className="text-2xl tracking-tight">{meta.title}</CardTitle>
                  <CardDescription>{meta.description}</CardDescription>
                </div>
                <Badge variant="secondary" className="gap-1.5 px-3 py-1 text-xs">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  Read-only admin surface
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {firstError ? (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Module data error</AlertTitle>
                  <AlertDescription>{firstError.message}</AlertDescription>
                </Alert>
              ) : null}

              {isAnyLoading ? (
                <Alert>
                  <ShieldCheck className="h-4 w-4" />
                  <AlertTitle>Loading module snapshot</AlertTitle>
                  <AlertDescription>
                    Typed queries are refreshing the current admin section. Summary cards and tables will populate as soon as the
                    module response arrives.
                  </AlertDescription>
                </Alert>
              ) : null}

              <Alert>
                <ShieldCheck className="h-4 w-4" />
                <AlertTitle>Safe operations boundary</AlertTitle>
                <AlertDescription>
                  Этот раздел визуализирует уже доступные backend-данные и безопасные состояния. Управляющие мутации и
                  production-инфраструктурные действия будут добавляться по мере закрытия backlog.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <SummaryRail
            pageKey={pageKey}
            jobs={jobsQuery.data ?? []}
            providers={proxyQuery.data?.providers ?? []}
            workers={workersQuery.data?.workers ?? []}
            billing={billingQuery.data ?? null}
            telemetry={telemetryQuery.data ?? null}
            system={systemQuery.data ?? null}
          />
        </section>

        {pageKey === "jobs" ? <JobsSection jobs={jobsQuery.data ?? []} /> : null}
        {pageKey === "proxy" ? <ProxySection proxy={proxyQuery.data ?? null} /> : null}
        {pageKey === "workers" ? <WorkersSection workers={workersQuery.data ?? null} /> : null}
        {pageKey === "billing" ? <BillingSection billing={billingQuery.data ?? null} /> : null}
        {pageKey === "telemetry" ? <TelemetrySection telemetry={telemetryQuery.data ?? null} /> : null}
        {pageKey === "system" ? <SystemSection system={systemQuery.data ?? null} /> : null}
      </div>
    </DashboardLayout>
  );
}

function SummaryRail({
  pageKey,
  jobs,
  providers,
  workers,
  billing,
  telemetry,
  system,
}: {
  pageKey: PageKey;
  jobs: Array<any>;
  providers: Array<any>;
  workers: Array<any>;
  billing: any;
  telemetry: any;
  system: any;
}) {
  const health = (telemetry?.health ?? system?.health ?? null) as HealthSnapshot | null;

  const cards: Record<PageKey, Array<{ label: string; value: string }>> = {
    jobs: [
      { label: "Jobs loaded", value: String(jobs.length) },
      { label: "Running", value: String(jobs.filter(job => job.status === "running").length) },
      { label: "Waiting retry", value: String(jobs.filter(job => job.status === "waiting_retry").length) },
    ],
    proxy: [
      { label: "Providers", value: String(providers.length) },
      { label: "Policies", value: String(proxyCountFromUnknown((providers as Array<any>).length, 0, providers.length)) },
      { label: "Health status", value: String(health?.status ?? "Unknown") },
    ],
    workers: [
      { label: "Workers", value: String(workers.length) },
      { label: "Healthy", value: String(health?.workers?.healthy ?? workers.filter(worker => worker.status === "healthy").length) },
      { label: "Busy", value: String(workers.filter(worker => worker.activeJobs > 0).length) },
    ],
    billing: [
      { label: "Plans", value: String(billing?.plans?.length ?? 0) },
      { label: "Subscriptions", value: String(billing?.subscriptions?.length ?? 0) },
      { label: "Payments", value: String(billing?.payments?.length ?? 0) },
    ],
    telemetry: [
      { label: "Success rate", value: formatPercent(telemetry?.successRate) },
      { label: "Retry rate", value: formatPercent(telemetry?.retryRate) },
      { label: "Audit events", value: String(telemetry?.recentAudit?.length ?? 0) },
    ],
    system: [
      { label: "Platform status", value: String(health?.status ?? "Unknown") },
      { label: "Safe scenarios", value: String(system?.safeTestScenarios?.length ?? 0) },
      { label: "Checklist items", value: String(system?.stabilizationChecklist?.length ?? 0) },
    ],
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle>Current module status</CardTitle>
        <CardDescription>Быстрый сводный срез по активному разделу админ-панели.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {cards[pageKey].map(card => (
          <div key={card.label} className="rounded-xl border bg-muted/30 p-4">
            <p className="text-sm text-muted-foreground">{card.label}</p>
            <p className="mt-2 text-lg font-semibold tracking-tight">{card.value}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function JobsSection({ jobs }: { jobs: Array<any> }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle>Job list</CardTitle>
        <CardDescription>Последние задания с режимом, источником, стоимостью и статусом.</CardDescription>
      </CardHeader>
      <CardContent>
        {jobs.length ? (
          <ScrollArea className="w-full">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job</TableHead>
                  <TableHead>Mode</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>ONE CS</TableHead>
                  <TableHead>Attempts</TableHead>
                  <TableHead>Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobs.map(job => (
                  <TableRow key={job.publicId}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{job.targetLabel ?? job.publicId}</p>
                        <p className="font-mono text-xs text-muted-foreground">{job.publicId}</p>
                      </div>
                    </TableCell>
                    <TableCell className="capitalize">{job.requestMode}</TableCell>
                    <TableCell className="capitalize">{job.source}</TableCell>
                    <TableCell>
                      <Badge variant={toneMap[job.status] ?? "outline"}>{job.status}</Badge>
                    </TableCell>
                    <TableCell>
                      {job.resultJson?.oneCsResult ? (
                        <div className="space-y-1 text-xs">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <Badge variant="secondary">CS {job.resultJson.oneCsResult.creditScore ?? "—"}</Badge>
                            <Badge variant="outline">P {job.resultJson.oneCsResult.productScore}/20</Badge>
                            <Badge variant="outline">Q {job.resultJson.oneCsResult.dataQualityScore}/10</Badge>
                          </div>
                          <p className="capitalize text-muted-foreground">{job.resultJson.oneCsResult.status.replace(/_/g, " ")}</p>
                          {Array.isArray(job.resultJson.oneCsResult.adverseReasons) && job.resultJson.oneCsResult.adverseReasons.length ? (
                            <p className="line-clamp-2 text-muted-foreground">
                              {job.resultJson.oneCsResult.adverseReasons.slice(0, 2).join("; ")}
                              {job.resultJson.oneCsResult.adverseReasons.length > 2 ? " …" : ""}
                            </p>
                          ) : (
                            <p className="text-muted-foreground">No adverse reasons</p>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {job.attemptCount}/{job.maxAttempts}
                    </TableCell>
                    <TableCell>${job.costEstimateUsd}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        ) : (
          <Empty>
            <EmptyHeader>
              <EmptyTitle>No jobs available</EmptyTitle>
              <EmptyDescription>Когда jobs-модуль вернёт записи, они появятся в этой таблице.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        )}
      </CardContent>
    </Card>
  );
}

function ProxySection({ proxy }: { proxy: any }) {
  const providers = proxy?.providers ?? [];
  const policies = proxy?.policies ?? [];
  const healthRows = proxy?.providerHealth ?? [];

  if (!providers.length && !policies.length && !healthRows.length) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Proxy module is empty</CardTitle>
          <CardDescription>Когда proxy summary вернёт провайдеров и policy, они появятся в этом разделе.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Providers</CardTitle>
          <CardDescription>Текущие провайдеры прокси с протоколами, priority и статусом.</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="w-full">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Cost / GB</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {providers.map((provider: any) => (
                  <TableRow key={provider.code}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{provider.name}</p>
                        <p className="text-xs text-muted-foreground">{provider.protocolSupport}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={toneMap[provider.status] ?? "outline"}>{provider.status}</Badge>
                    </TableCell>
                    <TableCell>{provider.priority}</TableCell>
                    <TableCell>${provider.costPerGbUsd}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Policies and health</CardTitle>
          <CardDescription>Policy-настройки маршрутизации и health summary по провайдерам.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            {policies.map((policy: any) => (
              <div key={policy.code} className="rounded-xl border bg-muted/20 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{policy.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {policy.protocol} · {policy.sessionMode} · retries {policy.maxTransportRetries}
                    </p>
                  </div>
                  <Badge variant={policy.isDefault === "yes" ? "secondary" : "outline"}>
                    {policy.isDefault === "yes" ? "Default" : "Optional"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-3">
            {healthRows.map((row: any) => (
              <div key={row.code} className="rounded-xl border bg-muted/20 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{row.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Health score {Math.round((row.healthScore ?? 0) * 100)}% · checked {String(row.lastCheckedAt)}
                    </p>
                  </div>
                  <Badge variant={toneMap[row.status] ?? "outline"}>{row.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}

function WorkersSection({ workers }: { workers: any }) {
  const workerRows = workers?.workers ?? [];
  const recommendations = workers?.recommendations ?? [];
  const queueHealth = workers?.queueHealth ?? {};

  if (!workerRows.length && !recommendations.length && !Object.keys(queueHealth).length) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Workers module is empty</CardTitle>
          <CardDescription>Когда workers summary вернёт узлы и queue health, они появятся в этом разделе.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Worker nodes</CardTitle>
          <CardDescription>Read-only срез по worker-узлам, heartbeat и concurrency.</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="w-full">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Worker</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Active / Limit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {workerRows.map((worker: any) => (
                  <TableRow key={worker.code}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{worker.name}</p>
                        <p className="text-xs text-muted-foreground">{worker.hostLabel}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={toneMap[worker.status] ?? "outline"}>{worker.status}</Badge>
                    </TableCell>
                    <TableCell>{worker.role}</TableCell>
                    <TableCell>
                      {worker.activeJobs}/{worker.concurrencyLimit}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Queue posture and recommendations</CardTitle>
          <CardDescription>Безопасные операторские подсказки для текущего execution-контура.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            {Object.entries(queueHealth).map(([queueName, queue]: [string, any]) => (
              <div key={queueName} className="rounded-xl border bg-muted/20 p-4">
                <p className="font-medium capitalize">{queueName}</p>
                <p className="mt-2 text-sm text-muted-foreground">Depth {queue.depth}</p>
                <p className="text-sm text-muted-foreground">Lag {queue.lagSeconds}s</p>
              </div>
            ))}
          </div>
          <div className="space-y-3">
            {recommendations.map((item: string) => (
              <div key={item} className="rounded-xl border bg-muted/20 p-4 text-sm text-muted-foreground">
                {item}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}

function BillingSection({ billing }: { billing: any }) {
  const plans = billing?.plans ?? [];
  const subscriptions = billing?.subscriptions ?? [];
  const payments = billing?.payments ?? [];
  const apiKeys = billing?.apiKeys ?? [];
  const usage = billing?.usageSummary ?? null;

  if (!plans.length && !subscriptions.length && !payments.length && !apiKeys.length && !usage) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Billing module is empty</CardTitle>
          <CardDescription>Когда billing summary вернёт тарифы, подписки и платежи, они появятся в этом разделе.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Plans and subscriptions</CardTitle>
          <CardDescription>Тарифы и активные подписки, доступные в read-only billing-витрине.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ScrollArea className="h-[260px] rounded-xl border bg-muted/10">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Plan</TableHead>
                  <TableHead>Tier</TableHead>
                  <TableHead>Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {plans.map((plan: any) => (
                  <TableRow key={plan.code}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{plan.name}</p>
                        <p className="text-xs text-muted-foreground">{plan.code}</p>
                      </div>
                    </TableCell>
                    <TableCell className="capitalize">{plan.tier}</TableCell>
                    <TableCell>{plan.currency} {plan.priceUsd}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>

          <div className="grid gap-3 sm:grid-cols-2">
            {subscriptions.map((subscription: any) => (
              <div key={subscription.id} className="rounded-xl border bg-muted/20 p-4">
                <p className="font-medium">Subscription #{subscription.id}</p>
                <p className="mt-2 text-sm text-muted-foreground">Provider {subscription.provider}</p>
                <Badge className="mt-3" variant={toneMap[subscription.status] ?? "outline"}>{subscription.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Payments and API keys</CardTitle>
          <CardDescription>Платежи, API-ключи и usage economics текущего периода.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {usage ? (
            <div className="grid gap-3 sm:grid-cols-2">
              <MetricChip label="Requests" value={String(usage.requests)} />
              <MetricChip label="Browser runs" value={String(usage.browserRuns)} />
              <MetricChip label="Revenue" value={`$${usage.revenueUsd}`} />
              <MetricChip label="Margin" value={`$${usage.marginUsd}`} />
            </div>
          ) : null}

          <div className="space-y-3">
            {payments.map((payment: any) => (
              <div key={payment.id} className="rounded-xl border bg-muted/20 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">Payment #{payment.id}</p>
                    <p className="text-xs text-muted-foreground">{payment.invoiceRef}</p>
                  </div>
                  <Badge variant={toneMap[payment.status] ?? "outline"}>{payment.status}</Badge>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{payment.currency} {payment.amount}</p>
              </div>
            ))}
          </div>

          <div className="space-y-3">
            {apiKeys.map((key: any) => (
              <div key={key.id} className="rounded-xl border bg-muted/20 p-4">
                <p className="font-medium">{key.label}</p>
                <p className="mt-1 font-mono text-xs text-muted-foreground">{key.keyPrefix}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}

function TelemetrySection({ telemetry }: { telemetry: any }) {
  const health = (telemetry?.health ?? null) as HealthSnapshot | null;
  const recentAudit = telemetry?.recentAudit ?? [];
  const counts = telemetry?.jobStatusCounts ?? {};

  return (
    <section className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Health counters</CardTitle>
          <CardDescription>Queue, provider and worker counters from telemetry summary.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <MetricChip label="Platform status" value={String(health?.status ?? "Unknown")} />
          <MetricChip label="Total jobs" value={String(counts.total ?? 0)} />
          <MetricChip label="Succeeded" value={String(counts.succeeded ?? 0)} />
          <MetricChip label="Waiting retry" value={String(counts.waiting_retry ?? 0)} />
          <MetricChip label="Workers healthy" value={String(health?.workers?.healthy ?? 0)} />
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Recent audit trail</CardTitle>
          <CardDescription>Последние audit-события из telemetry summary.</CardDescription>
        </CardHeader>
        <CardContent>
          {recentAudit.length ? (
            <div className="space-y-3">
              {recentAudit.map((entry: any) => (
                <div key={`${entry.action}-${entry.resourceId}-${entry.createdAt}`} className="rounded-xl border bg-muted/20 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-medium">{entry.action}</p>
                      <p className="text-xs text-muted-foreground">{entry.resourceType} · {entry.resourceId}</p>
                    </div>
                    <Badge variant="outline">{entry.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Empty>
              <EmptyHeader>
                <EmptyTitle>No telemetry audit yet</EmptyTitle>
                <EmptyDescription>События появятся здесь, когда telemetry-модуль вернёт данные.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          )}
        </CardContent>
      </Card>
    </section>
  );
}

function SystemSection({ system }: { system: any }) {
  const scenarios = system?.safeTestScenarios ?? [];
  const checklist = system?.stabilizationChecklist ?? [];

  if (!scenarios.length && !checklist.length) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>System module is empty</CardTitle>
          <CardDescription>Когда system summary вернёт safe scenarios и checklist, они появятся в этом разделе.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Safe test scenarios</CardTitle>
          <CardDescription>Доступные безопасные сценарии для операторской регрессии.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {scenarios.map((scenario: any) => (
            <div key={scenario.code} className="rounded-xl border bg-muted/20 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{scenario.title}</p>
                  <p className="text-xs text-muted-foreground">{scenario.code}</p>
                </div>
                <Badge variant="secondary">Safe</Badge>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{scenario.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Stabilization checklist</CardTitle>
          <CardDescription>Оставшиеся системные требования для перехода к production-grade контуру.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {checklist.map((item: string) => (
            <div key={item} className="rounded-xl border bg-muted/20 p-4 text-sm text-muted-foreground">
              {item}
            </div>
          ))}
        </CardContent>
      </Card>
    </section>
  );
}

function MetricChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border bg-muted/20 p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-2 text-lg font-semibold tracking-tight">{value}</p>
    </div>
  );
}

export function resolvePageKey(pathname: string): PageKey {
  if (pathname.startsWith("/proxy")) return "proxy";
  if (pathname.startsWith("/workers")) return "workers";
  if (pathname.startsWith("/billing")) return "billing";
  if (pathname.startsWith("/metrics") || pathname.startsWith("/telemetry")) return "telemetry";
  if (pathname.startsWith("/system")) return "system";
  return "jobs";
}

function formatPercent(input?: number) {
  if (typeof input !== "number" || Number.isNaN(input)) {
    return "—";
  }

  return `${(input * 100).toFixed(1)}%`;
}

function proxyCountFromUnknown(policyCount: number, _fallback: number, _providerCount: number) {
  return policyCount;
}
