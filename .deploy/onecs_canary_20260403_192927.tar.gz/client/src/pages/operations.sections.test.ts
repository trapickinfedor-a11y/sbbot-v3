import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = {
  location: "/jobs",
  queries: {
    jobs: { data: [], isLoading: false, error: null },
    proxy: { data: null, isLoading: false, error: null },
    workers: { data: null, isLoading: false, error: null },
    billing: { data: null, isLoading: false, error: null },
    telemetry: { data: null, isLoading: false, error: null },
    system: { data: null, isLoading: false, error: null },
  },
};

vi.mock("wouter", () => ({
  useLocation: () => [state.location, vi.fn()],
}));

vi.mock("@/components/DashboardLayout", () => ({
  default: ({ children }: { children: React.ReactNode }) => React.createElement("div", { "data-testid": "dashboard-layout" }, children),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    jobs: {
      list: {
        useQuery: () => state.queries.jobs,
      },
    },
    proxies: {
      summary: {
        useQuery: () => state.queries.proxy,
      },
    },
    workers: {
      summary: {
        useQuery: () => state.queries.workers,
      },
    },
    billing: {
      summary: {
        useQuery: () => state.queries.billing,
      },
    },
    telemetry: {
      summary: {
        useQuery: () => state.queries.telemetry,
      },
    },
    platform: {
      system: {
        useQuery: () => state.queries.system,
      },
    },
  },
}));

import Operations from "./Operations";

function resetState() {
  state.location = "/jobs";
  state.queries.jobs = { data: [], isLoading: false, error: null };
  state.queries.proxy = { data: null, isLoading: false, error: null };
  state.queries.workers = { data: null, isLoading: false, error: null };
  state.queries.billing = { data: null, isLoading: false, error: null };
  state.queries.telemetry = { data: null, isLoading: false, error: null };
  state.queries.system = { data: null, isLoading: false, error: null };
}

function renderPage(pathname: string) {
  state.location = pathname;
  return renderToStaticMarkup(React.createElement(Operations));
}

describe("admin operations sections", () => {
  beforeEach(() => {
    resetState();
  });

  it("shows a shared loading banner while typed queries are refreshing", () => {
    state.queries.jobs = { data: [], isLoading: true, error: null };

    const html = renderPage("/jobs");

    expect(html).toContain("Loading module snapshot");
    expect(html).toContain("Typed queries are refreshing the current admin section");
  });

  it("surfaces module query errors in the shared alert area", () => {
    state.queries.billing = {
      data: null,
      isLoading: false,
      error: { message: "billing summary unavailable" },
    };

    const html = renderPage("/billing");

    expect(html).toContain("Module data error");
    expect(html).toContain("billing summary unavailable");
  });

  it("renders the Jobs empty state when there are no jobs", () => {
    const html = renderPage("/jobs");

    expect(html).toContain("Job list");
    expect(html).toContain("No jobs available");
  });

  it("renders Proxy providers, policies and health rows when data is present", () => {
    state.queries.proxy = {
      data: {
        providers: [
          {
            code: "evomi",
            name: "Evomi",
            protocolSupport: "http/https",
            status: "healthy",
            priority: 1,
            costPerGbUsd: 2.5,
          },
        ],
        policies: [
          {
            code: "default-sticky",
            name: "Default sticky",
            protocol: "http",
            sessionMode: "sticky",
            maxTransportRetries: 2,
            isDefault: "yes",
          },
        ],
        providerHealth: [
          {
            code: "evomi",
            name: "Evomi",
            status: "healthy",
            healthScore: 0.98,
            lastCheckedAt: "2026-04-03T10:00:00.000Z",
          },
        ],
      },
      isLoading: false,
      error: null,
    };

    const html = renderPage("/proxy");

    expect(html).toContain("Providers");
    expect(html).toContain("Default sticky");
    expect(html).toContain("Evomi");
    expect(html).toContain("Policies and health");
  });

  it("renders Workers data-present state with worker nodes and recommendations", () => {
    state.queries.workers = {
      data: {
        workers: [
          {
            code: "worker-a",
            name: "Worker A",
            hostLabel: "host-a",
            status: "healthy",
            role: "default",
            activeJobs: 2,
            concurrencyLimit: 6,
          },
        ],
        recommendations: ["Increase retry visibility for bulk queue"],
        queueHealth: {
          default: { depth: 5, lagSeconds: 12 },
        },
      },
      isLoading: false,
      error: null,
    };

    const html = renderPage("/workers");

    expect(html).toContain("Worker nodes");
    expect(html).toContain("Worker A");
    expect(html).toContain("Increase retry visibility for bulk queue");
    expect(html).toContain("Depth 5");
  });

  it("renders Billing data-present state with plans, payments, usage and api keys", () => {
    state.queries.billing = {
      data: {
        plans: [
          {
            code: "pro",
            name: "Pro",
            tier: "pro",
            currency: "USD",
            priceUsd: 49,
          },
        ],
        subscriptions: [
          {
            id: 7,
            provider: "crypto-bot",
            status: "active",
          },
        ],
        payments: [
          {
            id: 15,
            invoiceRef: "INV-015",
            status: "confirmed",
            currency: "USD",
            amount: 49,
          },
        ],
        apiKeys: [
          {
            id: 2,
            label: "VIP ingestion key",
            keyPrefix: "vip_abc",
          },
        ],
        usageSummary: {
          requests: 120,
          browserRuns: 18,
          revenueUsd: 49,
          marginUsd: 31,
        },
      },
      isLoading: false,
      error: null,
    };

    const html = renderPage("/billing");

    expect(html).toContain("Plans and subscriptions");
    expect(html).toContain("Pro");
    expect(html).toContain("Subscription #7");
    expect(html).toContain("Payment #15");
    expect(html).toContain("VIP ingestion key");
    expect(html).toContain("Browser runs");
  });

  it("renders Metrics health counters and telemetry empty-audit state", () => {
    state.queries.telemetry = {
      data: {
        successRate: 0.984,
        retryRate: 0.021,
        jobStatusCounts: {
          total: 24,
          succeeded: 22,
          waiting_retry: 1,
        },
        health: {
          status: "healthy",
          workers: { healthy: 3 },
        },
        recentAudit: [],
      },
      isLoading: false,
      error: null,
    };

    const html = renderPage("/metrics");

    expect(html).toContain("Health counters");
    expect(html).toContain("Platform status");
    expect(html).toContain("healthy");
    expect(html).toContain("No telemetry audit yet");
  });

  it("renders System data-present state with safe scenarios and stabilization checklist", () => {
    state.queries.system = {
      data: {
        safeTestScenarios: [
          {
            code: "safe-import-preview",
            title: "Safe import preview",
            description: "Preview imported records without touching external systems.",
          },
        ],
        stabilizationChecklist: ["Confirm retry alerts before enabling new queues"],
      },
      isLoading: false,
      error: null,
    };

    const html = renderPage("/system");

    expect(html).toContain("Safe test scenarios");
    expect(html).toContain("Safe import preview");
    expect(html).toContain("Stabilization checklist");
    expect(html).toContain("Confirm retry alerts before enabling new queues");
  });
});
