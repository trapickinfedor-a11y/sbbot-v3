import { describe, expect, it } from "vitest";
import { adminRoutes } from "../App";
import { pageMeta, resolvePageKey } from "./Operations";

describe("admin panel route mapping", () => {
  it("registers all major admin routes as separate entries", () => {
    expect(adminRoutes).toEqual([
      "/",
      "/imported-data",
      "/jobs",
      "/proxy",
      "/workers",
      "/billing",
      "/metrics",
      "/telemetry",
      "/system",
    ]);
  });

  it("maps each operations path to the expected module key", () => {
    expect(resolvePageKey("/jobs")).toBe("jobs");
    expect(resolvePageKey("/proxy")).toBe("proxy");
    expect(resolvePageKey("/workers")).toBe("workers");
    expect(resolvePageKey("/billing")).toBe("billing");
    expect(resolvePageKey("/metrics")).toBe("telemetry");
    expect(resolvePageKey("/telemetry")).toBe("telemetry");
    expect(resolvePageKey("/system")).toBe("system");
  });

  it("keeps a dedicated metadata entry for each typed-query operations section", () => {
    expect(Object.keys(pageMeta).sort()).toEqual([
      "billing",
      "jobs",
      "proxy",
      "system",
      "telemetry",
      "workers",
    ]);
    expect(pageMeta.jobs.title).toBe("Jobs");
    expect(pageMeta.proxy.title).toBe("Proxy");
    expect(pageMeta.workers.title).toBe("Workers");
    expect(pageMeta.billing.title).toBe("Billing");
    expect(pageMeta.telemetry.title).toBe("Metrics");
    expect(pageMeta.system.title).toBe("System");
  });
});
